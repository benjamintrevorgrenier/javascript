document.write("This is a javascript coding bla bla bla");

console.log("This is text that will go directly to developers");
